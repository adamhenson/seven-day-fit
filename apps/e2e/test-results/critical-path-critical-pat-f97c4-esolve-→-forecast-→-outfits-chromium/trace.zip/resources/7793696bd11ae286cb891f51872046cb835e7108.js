(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ab424890._.js",
  "static/chunks/abe51_next_dist_compiled_react-dom_a5d718ef._.js",
  "static/chunks/abe51_next_dist_compiled_next-devtools_index_de5b88aa.js",
  "static/chunks/abe51_next_dist_compiled_d308f5b4._.js",
  "static/chunks/abe51_next_dist_client_4b5a4c85._.js",
  "static/chunks/abe51_next_dist_79f82a47._.js",
  "static/chunks/abe51_@swc_helpers_cjs_bb200d6e._.js"
],
    source: "entry"
});
