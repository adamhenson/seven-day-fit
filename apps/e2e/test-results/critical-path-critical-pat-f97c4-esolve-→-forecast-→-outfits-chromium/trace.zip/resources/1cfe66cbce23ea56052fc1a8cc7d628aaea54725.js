(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/seven-day-fit/apps/web/lib/outfit-display.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "visualForPresetMap",
    ()=>visualForPresetMap,
    "visualsForPresets",
    ()=>visualsForPresets
]);
const visualForPresetMap = new Map([
    [
        'EXTREME_COLD_FULL',
        {
            icon: '🥶',
            label: 'extreme cold bundle'
        }
    ],
    [
        'VERY_COLD_LAYERED',
        {
            icon: '🧥🧣',
            label: 'heavy layers'
        }
    ],
    [
        'COLD_JACKET',
        {
            icon: '🧥',
            label: 'jacket'
        }
    ],
    [
        'COOL_LIGHT_LAYER',
        {
            icon: '🧥',
            label: 'light layer'
        }
    ],
    [
        'MILD_CASUAL',
        {
            icon: '👕',
            label: 'casual'
        }
    ],
    [
        'WARM_SHORT_SLEEVE',
        {
            icon: '☀️👕',
            label: 'short sleeve'
        }
    ],
    [
        'HOT_ULTRALIGHT',
        {
            icon: '☀️🩳',
            label: 'ultralight'
        }
    ],
    [
        'RAIN_COOL',
        {
            icon: '🌧️🧥',
            label: 'rain shell + layer'
        }
    ],
    [
        'RAIN_WARM',
        {
            icon: '🌧️',
            label: 'rain shell'
        }
    ],
    [
        'SNOW_GEAR',
        {
            icon: '❄️🧥',
            label: 'snow gear'
        }
    ],
    [
        'WIND_LAYER_ADDON',
        {
            icon: '💨',
            label: 'wind layer'
        }
    ]
]);
const visualsForPresets = (param)=>{
    let { presets } = param;
    return presets.map((p)=>{
        var _visualForPresetMap_get;
        return (_visualForPresetMap_get = visualForPresetMap.get(p)) !== null && _visualForPresetMap_get !== void 0 ? _visualForPresetMap_get : {
            icon: '👕',
            label: 'unknown'
        };
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/components/DayCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DayCard",
    ()=>DayCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$outfit$2d$display$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/lib/outfit-display.ts [app-client] (ecmascript)");
;
;
const DayCard = (param)=>{
    let { day, outfit, notes } = param;
    const weekday = new Date("".concat(day.dateISO, "T12:00:00")).toLocaleDateString(undefined, {
        weekday: 'short'
    });
    const low = Math.round(day.low);
    const high = Math.round(day.high);
    const tempLine = "".concat(low, "° - ").concat(high, "°").concat(day.summary ? " ".concat(day.summary) : '');
    const outfitLabels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$outfit$2d$display$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visualsForPresets"])({
        presets: outfit
    }).map((v)=>v.label).join(' + ');
    const notesInline = (notes || []).map((n)=>n.toLowerCase().replace('spf', 'SPF')).join(', ');
    const recLine = notesInline ? "".concat(outfitLabels, ", ").concat(notesInline) : outfitLabels;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-lg border p-6 text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-1 text-2xl font-semibold",
                children: weekday
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/components/DayCard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 text-base text-muted-foreground",
                children: tempLine
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/components/DayCard.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex flex-wrap items-center justify-center gap-3 text-5xl",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$outfit$2d$display$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visualsForPresets"])({
                    presets: outfit
                }).map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "aria-hidden": "true",
                        children: v.icon
                    }, v.label, false, {
                        fileName: "[project]/seven-day-fit/apps/web/components/DayCard.tsx",
                        lineNumber: 39,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/components/DayCard.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-base font-semibold",
                children: recLine
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/components/DayCard.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/seven-day-fit/apps/web/components/DayCard.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = DayCard;
var _c;
__turbopack_context__.k.register(_c, "DayCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/components/HeightTransition.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeightTransition",
    ()=>HeightTransition
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const HeightTransition = (param)=>{
    let { children, show, durationMs = 250 } = param;
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [height, setHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Measure immediately when visibility changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "HeightTransition.useLayoutEffect": ()=>{
            if (!show) {
                setHeight(0);
                return;
            }
            const node = contentRef.current;
            setHeight(node ? node.offsetHeight : 0);
        }
    }["HeightTransition.useLayoutEffect"], [
        show
    ]);
    // Track content size changes while visible
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeightTransition.useEffect": ()=>{
            if (!show) return;
            const node = contentRef.current;
            if (!node || typeof ResizeObserver === 'undefined') return;
            const ro = new ResizeObserver({
                "HeightTransition.useEffect": ()=>{
                    setHeight(node.offsetHeight);
                }
            }["HeightTransition.useEffect"]);
            ro.observe(node);
            return ({
                "HeightTransition.useEffect": ()=>ro.disconnect()
            })["HeightTransition.useEffect"];
        }
    }["HeightTransition.useEffect"], [
        show
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        style: {
            height,
            transition: "height ".concat(durationMs, "ms ease")
        },
        className: "overflow-hidden",
        "aria-live": "polite",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: contentRef,
            children: show ? children : null
        }, void 0, false, {
            fileName: "[project]/seven-day-fit/apps/web/components/HeightTransition.tsx",
            lineNumber: 57,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/seven-day-fit/apps/web/components/HeightTransition.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(HeightTransition, "zAFh3PMQ6vNUJ579t/Y5OhXJK9g=");
_c = HeightTransition;
var _c;
__turbopack_context__.k.register(_c, "HeightTransition");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/components/StatusBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StatusBanner",
    ()=>StatusBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
const StatusBanner = (param)=>{
    let { indicator, message, tone, effect, children } = param;
    const containerTone = tone === 'muted' ? 'border-neutral-300 bg-neutral-100 text-neutral-800 dark:border-neutral-800 dark:bg-neutral-950 dark:text-neutral-200' : 'border-neutral-300 bg-white text-neutral-900 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100';
    const effectClass = effect === 'flash' ? 'flash-text' : effect === 'shimmer' ? 'shimmer-text' : '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto w-full max-w-xl rounded-md border px-3 py-2 text-sm shadow-sm ".concat(containerTone),
        "aria-live": "polite",
        "aria-atomic": "true",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start gap-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-0.5 flex h-4 w-4 items-center justify-center",
                    "aria-hidden": "true",
                    children: indicator === 'spinner' ? // neutral spinner
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "h-4 w-4 animate-spin text-neutral-500",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": "true",
                        focusable: "false",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                className: "opacity-25",
                                cx: "12",
                                cy: "12",
                                r: "10",
                                stroke: "currentColor",
                                strokeWidth: "3"
                            }, void 0, false, {
                                fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                                lineNumber: 56,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                className: "opacity-75",
                                d: "M22 12c0-5.523-4.477-10-10-10",
                                stroke: "currentColor",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }, void 0, false, {
                                fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                                lineNumber: 64,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                        lineNumber: 48,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)) : indicator === 'check' ? // grey/black check (not green)
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "h-4 w-4 text-neutral-700 dark:text-neutral-300",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": "true",
                        focusable: "false",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M5 12.5l4.5 4.5L19.5 7.5",
                            stroke: "currentColor",
                            strokeWidth: "2.5",
                            strokeLinecap: "round",
                            strokeLinejoin: "round"
                        }, void 0, false, {
                            fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                            lineNumber: 82,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                        lineNumber: 74,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)) : // exclamation triangle in neutral tone
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "h-4 w-4 text-neutral-700 dark:text-neutral-300",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": "true",
                        focusable: "false",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M12 3l9 16H3l9-16z",
                                stroke: "currentColor",
                                strokeWidth: "1.8",
                                strokeLinejoin: "round"
                            }, void 0, false, {
                                fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                                lineNumber: 100,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M12 9v5",
                                stroke: "currentColor",
                                strokeWidth: "1.8",
                                strokeLinecap: "round"
                            }, void 0, false, {
                                fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                                lineNumber: 106,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                cx: "12",
                                cy: "16.5",
                                r: "0.9",
                                fill: "currentColor"
                            }, void 0, false, {
                                fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                                lineNumber: 107,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                        lineNumber: 92,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 leading-5 ".concat(effectClass),
                    children: children !== null && children !== void 0 ? children : message
                }, void 0, false, {
                    fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
                    lineNumber: 111,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
            lineNumber: 44,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/seven-day-fit/apps/web/components/StatusBanner.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = StatusBanner;
var _c;
__turbopack_context__.k.register(_c, "StatusBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/components/ResultStatus.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResultStatus",
    ()=>ResultStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$HeightTransition$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/components/HeightTransition.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$StatusBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/components/StatusBanner.tsx [app-client] (ecmascript)");
'use client';
;
;
;
const ResultStatus = (param)=>{
    let { advice, confidence, days, loading, locationLabel, step } = param;
    const banner = loading ? {
        indicator: step >= 2 ? 'check' : 'spinner',
        message: step === 0 ? 'Resolving location...' : 'Fetching forecast...',
        effect: 'shimmer'
    } : locationLabel && typeof confidence === 'number' && days ? {
        indicator: confidence >= 0.7 ? 'check' : 'warn',
        message: "Confidence ".concat((confidence * 100).toFixed(0), "%.").concat(confidence < 0.7 && advice ? " ".concat(advice) : '')
    } : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$HeightTransition$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeightTransition"], {
        show: !!banner,
        children: banner ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$StatusBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StatusBanner"], {
            indicator: banner.indicator,
            message: banner.message,
            tone: "muted",
            effect: banner.effect
        }, void 0, false, {
            fileName: "[project]/seven-day-fit/apps/web/components/ResultStatus.tsx",
            lineNumber: 61,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)) : null
    }, void 0, false, {
        fileName: "[project]/seven-day-fit/apps/web/components/ResultStatus.tsx",
        lineNumber: 59,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = ResultStatus;
var _c;
__turbopack_context__.k.register(_c, "ResultStatus");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/components/SearchBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SearchBar",
    ()=>SearchBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
const SearchBar = (param)=>{
    let { onSubmit, placeholder, disabled } = param;
    const handleSubmit = (event)=>{
        event.preventDefault();
        if (disabled) return;
        const form = event.currentTarget;
        const formData = new FormData(form);
        var _formData_get;
        const value = String((_formData_get = formData.get('q')) !== null && _formData_get !== void 0 ? _formData_get : '').trim();
        if (value) onSubmit(value);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: "mx-auto w-full max-w-xl",
        autoComplete: "off",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    id: "search-input",
                    name: "q",
                    placeholder: placeholder !== null && placeholder !== void 0 ? placeholder : '"the big apple", "Mission, SF", or a riddle...',
                    className: "w-full rounded-md border px-3 pr-12 py-2 outline-none ".concat(disabled ? 'border-neutral-700 bg-background/60 text-neutral-400' : 'bg-background focus:border-foreground'),
                    "aria-label": "Free-text location",
                    autoComplete: "off",
                    autoCorrect: "off",
                    autoCapitalize: "none",
                    spellCheck: false,
                    type: "search",
                    inputMode: "search",
                    disabled: disabled,
                    "aria-disabled": disabled ? true : undefined
                }, void 0, false, {
                    fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "submit",
                    "aria-label": "Search",
                    className: "absolute right-2 top-1/2 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full shadow-sm transition-opacity focus:outline-none focus:ring-2 cursor-pointer ".concat(disabled ? 'bg-neutral-700 text-neutral-400 opacity-70 cursor-not-allowed' : 'bg-foreground text-background hover:opacity-90 focus:ring-foreground/40'),
                    disabled: disabled,
                    "aria-disabled": disabled ? true : undefined,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            className: "h-4 w-4",
                            "aria-hidden": "true",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M5 12h12",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    strokeLinecap: "round"
                                }, void 0, false, {
                                    fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M13 5l7 7-7 7",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                }, void 0, false, {
                                    fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "sr-only",
                            children: "Search"
                        }, void 0, false, {
                            fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/seven-day-fit/apps/web/components/SearchBar.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SearchBar;
var _c;
__turbopack_context__.k.register(_c, "SearchBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/components/Toast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toast",
    ()=>Toast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const Toast = (param)=>{
    let { message, durationMs = 3500, onClose } = param;
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toast.useEffect": ()=>{
            if (!message) return;
            const id = window.setTimeout({
                "Toast.useEffect.id": ()=>{
                    onClose === null || onClose === void 0 ? void 0 : onClose();
                }
            }["Toast.useEffect.id"], durationMs);
            return ({
                "Toast.useEffect": ()=>window.clearTimeout(id)
            })["Toast.useEffect"];
        }
    }["Toast.useEffect"], [
        message,
        durationMs,
        onClose
    ]);
    if (!message) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "pointer-events-none fixed left-1/2 top-4 z-50 -translate-x-1/2 transform",
        "aria-live": "polite",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pointer-events-auto rounded-md border border-neutral-700 bg-neutral-900 px-4 py-2 text-sm text-neutral-100 shadow-lg",
            children: message
        }, void 0, false, {
            fileName: "[project]/seven-day-fit/apps/web/components/Toast.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/seven-day-fit/apps/web/components/Toast.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Toast, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Toast;
var _c;
__turbopack_context__.k.register(_c, "Toast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/lib/outfit.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapWeeklyOutfits",
    ()=>mapWeeklyOutfits,
    "normalizeOpenMeteo",
    ()=>normalizeOpenMeteo,
    "outfitForDay",
    ()=>outfitForDay
]);
const outfitForDay = (param)=>{
    let { day } = param;
    var _day_feelsLikeHigh;
    const feelsLikeHigh = (_day_feelsLikeHigh = day.feelsLikeHigh) !== null && _day_feelsLikeHigh !== void 0 ? _day_feelsLikeHigh : day.high;
    const temperature = Math.round(feelsLikeHigh);
    var _day_maxGust, _day_wind;
    const isWindy = ((_day_maxGust = day.maxGust) !== null && _day_maxGust !== void 0 ? _day_maxGust : 0) >= 30 || ((_day_wind = day.wind) !== null && _day_wind !== void 0 ? _day_wind : 0) >= 20;
    var _day_pop;
    const isRainy = day.precipType === 'rain' && ((_day_pop = day.pop) !== null && _day_pop !== void 0 ? _day_pop : 0) >= 0.4;
    const isSnowy = day.precipType === 'snow';
    var _day_uvIndex;
    const isUvHigh = ((_day_uvIndex = day.uvIndex) !== null && _day_uvIndex !== void 0 ? _day_uvIndex : 0) >= 7;
    if (isSnowy) {
        return {
            outfit: [
                'SNOW_GEAR'
            ],
            notes: []
        };
    }
    if (isRainy) {
        return {
            outfit: [
                feelsLikeHigh <= 64 ? 'RAIN_COOL' : 'RAIN_WARM'
            ],
            notes: isWindy ? [
                'Add wind shell'
            ] : []
        };
    }
    let base;
    if (temperature <= 10) base = 'EXTREME_COLD_FULL';
    else if (temperature <= 29) base = 'VERY_COLD_LAYERED';
    else if (temperature <= 49) base = 'COLD_JACKET';
    else if (temperature <= 64) base = 'COOL_LIGHT_LAYER';
    else if (temperature <= 79) base = 'MILD_CASUAL';
    else if (temperature <= 90) base = 'WARM_SHORT_SLEEVE';
    else base = 'HOT_ULTRALIGHT';
    const outfit = isWindy ? [
        base,
        'WIND_LAYER_ADDON'
    ] : [
        base
    ];
    const notes = [
        ...isUvHigh ? [
            'Hat & SPF'
        ] : [],
        ...day.low !== undefined && day.low < 58 && base === 'MILD_CASUAL' ? [
            'Light layer AM/PM'
        ] : []
    ];
    return {
        outfit,
        notes
    };
};
const normalizeOpenMeteo = (param)=>{
    let { daily } = param;
    const days = [];
    for(let i = 0; i < daily.time.length; i += 1){
        var _daily_apparent_temperature_max, _daily_precipitation_probability_max, _daily_windspeed_10m_max, _daily_wind_gusts_10m_max, _daily_uv_index_max, _daily_weathercode, _daily_snowfall_sum, _daily_precipitation_sum;
        const dateISO = String(daily.time[i]);
        const high = Number(daily['temperature_2m_max'][i]);
        const low = Number(daily['temperature_2m_min'][i]);
        var _daily_apparent_temperature_max_i;
        const feelsLikeHigh = (_daily_apparent_temperature_max_i = (_daily_apparent_temperature_max = daily['apparent_temperature_max']) === null || _daily_apparent_temperature_max === void 0 ? void 0 : _daily_apparent_temperature_max[i]) !== null && _daily_apparent_temperature_max_i !== void 0 ? _daily_apparent_temperature_max_i : null;
        var _daily_precipitation_probability_max_i;
        const popPct = (_daily_precipitation_probability_max_i = (_daily_precipitation_probability_max = daily['precipitation_probability_max']) === null || _daily_precipitation_probability_max === void 0 ? void 0 : _daily_precipitation_probability_max[i]) !== null && _daily_precipitation_probability_max_i !== void 0 ? _daily_precipitation_probability_max_i : null;
        var _daily_windspeed_10m_max_i;
        const wind = (_daily_windspeed_10m_max_i = (_daily_windspeed_10m_max = daily['windspeed_10m_max']) === null || _daily_windspeed_10m_max === void 0 ? void 0 : _daily_windspeed_10m_max[i]) !== null && _daily_windspeed_10m_max_i !== void 0 ? _daily_windspeed_10m_max_i : null;
        var _daily_wind_gusts_10m_max_i;
        const maxGust = (_daily_wind_gusts_10m_max_i = (_daily_wind_gusts_10m_max = daily['wind_gusts_10m_max']) === null || _daily_wind_gusts_10m_max === void 0 ? void 0 : _daily_wind_gusts_10m_max[i]) !== null && _daily_wind_gusts_10m_max_i !== void 0 ? _daily_wind_gusts_10m_max_i : null;
        var _daily_uv_index_max_i;
        const uvIndex = (_daily_uv_index_max_i = (_daily_uv_index_max = daily['uv_index_max']) === null || _daily_uv_index_max === void 0 ? void 0 : _daily_uv_index_max[i]) !== null && _daily_uv_index_max_i !== void 0 ? _daily_uv_index_max_i : null;
        var _daily_weathercode_i;
        const weatherCode = (_daily_weathercode_i = (_daily_weathercode = daily['weathercode']) === null || _daily_weathercode === void 0 ? void 0 : _daily_weathercode[i]) !== null && _daily_weathercode_i !== void 0 ? _daily_weathercode_i : null;
        var _daily_snowfall_sum_i;
        const snowfall = (_daily_snowfall_sum_i = (_daily_snowfall_sum = daily['snowfall_sum']) === null || _daily_snowfall_sum === void 0 ? void 0 : _daily_snowfall_sum[i]) !== null && _daily_snowfall_sum_i !== void 0 ? _daily_snowfall_sum_i : 0;
        var _daily_precipitation_sum_i;
        const precipSum = (_daily_precipitation_sum_i = (_daily_precipitation_sum = daily['precipitation_sum']) === null || _daily_precipitation_sum === void 0 ? void 0 : _daily_precipitation_sum[i]) !== null && _daily_precipitation_sum_i !== void 0 ? _daily_precipitation_sum_i : 0;
        const pop = popPct == null ? undefined : Math.max(0, Math.min(1, popPct / 100));
        const precipType = snowfall && snowfall > 0 ? 'snow' : (precipSum !== null && precipSum !== void 0 ? precipSum : 0) > 0 ? 'rain' : 'none';
        days.push({
            dateISO,
            high,
            low,
            feelsLikeHigh: feelsLikeHigh !== null && feelsLikeHigh !== void 0 ? feelsLikeHigh : undefined,
            precipType: precipType === 'none' ? undefined : precipType,
            pop,
            wind: wind !== null && wind !== void 0 ? wind : undefined,
            maxGust: maxGust !== null && maxGust !== void 0 ? maxGust : undefined,
            uvIndex: uvIndex !== null && uvIndex !== void 0 ? uvIndex : undefined,
            summary: weatherCodeToSummary(weatherCode !== null && weatherCode !== void 0 ? weatherCode : undefined)
        });
    }
    return days;
};
/**
 * Map Open-Meteo WMO weather codes to a compact human summary.
 * @see {@link https://artefacts.ceda.ac.uk/badc_datadocs/surface/code.html | WMO weather codes}
 */ const weatherCodeToSummary = (code)=>{
    if (typeof code !== 'number') return undefined;
    // Minimal set covering common conditions; extend as needed
    if (code === 0) return 'clear';
    if (code === 1 || code === 2) return 'mostly clear';
    if (code === 3) return 'overcast';
    if (code === 45 || code === 48) return 'foggy';
    if ([
        51,
        53,
        55
    ].includes(code)) return 'drizzle';
    if ([
        56,
        57
    ].includes(code)) return 'freezing drizzle';
    if ([
        61,
        63,
        65
    ].includes(code)) return 'rain';
    if ([
        66,
        67
    ].includes(code)) return 'freezing rain';
    if ([
        71,
        73,
        75
    ].includes(code)) return 'snow';
    if (code === 77) return 'snow grains';
    if ([
        80,
        81,
        82
    ].includes(code)) return 'showers';
    if ([
        85,
        86
    ].includes(code)) return 'snow showers';
    if ([
        95
    ].includes(code)) return 'thunderstorm';
    if ([
        96,
        99
    ].includes(code)) return 'thunderstorm + hail';
    return undefined;
};
const mapWeeklyOutfits = (param)=>{
    let { days } = param;
    return days.map((d)=>outfitForDay({
            day: d
        }));
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/lib/useSearch.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSearch",
    ()=>useSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$outfit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/lib/outfit.ts [app-client] (ecmascript)");
'use client';
;
;
const useSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
        advice: null,
        confidence: null,
        days: null,
        loading: false,
        locationLabel: null,
        outfits: null,
        step: 0,
        toast: null,
        /**
   * Set or clear the toast message.
   */ setToast: (msg)=>set({
                toast: msg
            }),
        /**
   * Reset volatile state back to an idle baseline.
   */ reset: ()=>set({
                advice: null,
                confidence: null,
                days: null,
                outfits: null,
                locationLabel: null,
                step: 0
            }),
        /**
   * Execute the end-to-end search flow.
   *
   * Params:
   *  - input: free-text description to resolve into a location candidate
   */ runSearch: async (input)=>{
            if (!input.trim()) return;
            set({
                loading: true,
                step: 0,
                advice: null,
                locationLabel: null,
                days: null,
                outfits: null
            });
            try {
                // Resolve
                set({
                    step: 0
                });
                const resolveRes = await fetch('/api/resolve-location', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        input
                    })
                });
                if (!resolveRes.ok) throw new Error('Failed to resolve location');
                const data = await resolveRes.json();
                if (!data.location) {
                    const msg = !data.advice ? 'Try a clearer place name.' : data.advice;
                    set({
                        toast: "We couldn't resolve that description. ".concat(msg)
                    });
                    set({
                        loading: false
                    });
                    return;
                }
                var _data_location_confidence, _data_advice;
                set({
                    locationLabel: data.location.displayName,
                    confidence: (_data_location_confidence = data.location.confidence) !== null && _data_location_confidence !== void 0 ? _data_location_confidence : null,
                    advice: (_data_advice = data.advice) !== null && _data_advice !== void 0 ? _data_advice : null
                });
                // Forecast
                set({
                    step: 1
                });
                const forecastRes = await fetch('/api/forecast', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        lat: data.location.lat,
                        lon: data.location.lon
                    })
                });
                if (!forecastRes.ok) {
                    let message = 'Failed to fetch forecast';
                    try {
                        const errJson = await forecastRes.json();
                        if (errJson === null || errJson === void 0 ? void 0 : errJson.error) message = errJson.error;
                    } catch (e) {}
                    set({
                        toast: message,
                        loading: false
                    });
                    return;
                }
                const { days } = await forecastRes.json();
                set({
                    days
                });
                // Map outfits
                set({
                    step: 2
                });
                const mapped = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$outfit$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapWeeklyOutfits"])({
                    days
                }).map((o, idx)=>({
                        dateISO: days[idx].dateISO,
                        high: days[idx].high,
                        low: days[idx].low,
                        feelsLikeHigh: days[idx].feelsLikeHigh,
                        precipType: days[idx].precipType,
                        pop: days[idx].pop,
                        wind: days[idx].wind,
                        maxGust: days[idx].maxGust,
                        uvIndex: days[idx].uvIndex,
                        summary: days[idx].summary,
                        outfit: o.outfit,
                        notes: o.notes
                    }));
                set({
                    outfits: mapped,
                    step: 3
                });
            } catch (e) {
                set({
                    toast: e.message
                });
            } finally{
                set({
                    loading: false
                });
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/apps/web/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$DayCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/components/DayCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$ResultStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/components/ResultStatus.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/components/SearchBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/components/Toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$useSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/apps/web/lib/useSearch.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function Home() {
    _s();
    const { advice, confidence, days, loading, locationLabel, outfits, step, toast, setToast, runSearch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$useSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearch"])();
    const handleSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSearch]": (input)=>runSearch(input)
    }["Home.useCallback[handleSearch]"], [
        runSearch
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mx-auto flex min-h-screen max-w-7xl flex-col gap-8 p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto mt-16 w-full max-w-xl text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "mb-2 text-3xl font-semibold",
                        children: "Seven Day Fit"
                    }, void 0, false, {
                        fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted-foreground",
                        children: "Describe a place and we'll dress you for the week."
                    }, void 0, false, {
                        fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$SearchBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchBar"], {
                onSubmit: handleSearch,
                disabled: loading
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$ResultStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResultStatus"], {
                advice: advice,
                confidence: confidence,
                days: days,
                loading: loading,
                locationLabel: locationLabel,
                step: step
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toast"], {
                message: toast,
                onClose: ()=>setToast(null)
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this),
            outfits && days && locationLabel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-center text-xl text-muted-foreground",
                children: locationLabel
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                lineNumber: 52,
                columnNumber: 9
            }, this) : null,
            outfits && days ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7",
                children: outfits.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$components$2f$DayCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DayCard"], {
                        day: d,
                        outfit: d.outfit,
                        notes: d.notes
                    }, d.dateISO, false, {
                        fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                        lineNumber: 59,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
                lineNumber: 57,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/seven-day-fit/apps/web/app/page.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(Home, "0ekz7DG+EWUIanswsinp2WNkorI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$apps$2f$web$2f$lib$2f$useSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearch"]
    ];
});
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/seven-day-fit/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        "object" === typeof node && null !== node && node.$$typeof === REACT_ELEMENT_TYPE && node._store && (node._store.validated = 1);
    }
    var React = __turbopack_context__.r("[project]/seven-day-fit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/seven-day-fit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/seven-day-fit/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/seven-day-fit/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStore",
    ()=>createStore
]);
const createStoreImpl = (createState)=>{
    let state;
    const listeners = /* @__PURE__ */ new Set();
    const setState = (partial, replace)=>{
        const nextState = typeof partial === "function" ? partial(state) : partial;
        if (!Object.is(nextState, state)) {
            const previousState = state;
            state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
            listeners.forEach((listener)=>listener(state, previousState));
        }
    };
    const getState = ()=>state;
    const getInitialState = ()=>initialState;
    const subscribe = (listener)=>{
        listeners.add(listener);
        return ()=>listeners.delete(listener);
    };
    const api = {
        setState,
        getState,
        getInitialState,
        subscribe
    };
    const initialState = state = createState(setState, getState, api);
    return api;
};
const createStore = (createState)=>createState ? createStoreImpl(createState) : createStoreImpl;
;
}),
"[project]/seven-day-fit/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "create",
    ()=>create,
    "useStore",
    ()=>useStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/seven-day-fit/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)");
;
;
const identity = (arg)=>arg;
function useStore(api) {
    let selector = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : identity;
    const slice = __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useSyncExternalStore(api.subscribe, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useStore.useSyncExternalStore[slice]": ()=>selector(api.getState())
    }["useStore.useSyncExternalStore[slice]"], [
        api,
        selector
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useStore.useSyncExternalStore[slice]": ()=>selector(api.getInitialState())
    }["useStore.useSyncExternalStore[slice]"], [
        api,
        selector
    ]));
    __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue(slice);
    return slice;
}
const createImpl = (createState)=>{
    const api = (0, __TURBOPACK__imported__module__$5b$project$5d2f$seven$2d$day$2d$fit$2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(createState);
    const useBoundStore = (selector)=>useStore(api, selector);
    Object.assign(useBoundStore, api);
    return useBoundStore;
};
const create = (createState)=>createState ? createImpl(createState) : createImpl;
;
}),
]);

//# sourceMappingURL=seven-day-fit_d9fea3c7._.js.map